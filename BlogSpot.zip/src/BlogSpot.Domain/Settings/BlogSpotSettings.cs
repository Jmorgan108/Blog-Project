﻿namespace BlogSpot.Settings;

public static class BlogSpotSettings
{
    private const string Prefix = "BlogSpot";

    //Add your own setting names here. Example:
    //public const string MySetting1 = Prefix + ".MySetting1";
}
