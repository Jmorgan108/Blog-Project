﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("BlogSpot.Application.Tests")]
