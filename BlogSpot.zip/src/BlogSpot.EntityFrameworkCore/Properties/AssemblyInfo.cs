﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("BlogSpot.EntityFrameworkCore.Tests")]
