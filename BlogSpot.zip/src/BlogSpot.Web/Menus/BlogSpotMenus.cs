﻿namespace BlogSpot.Web.Menus;

public class BlogSpotMenus
{
    private const string Prefix = "BlogSpot";
    public const string Home = Prefix + ".Home";

    //Add your menu items here...

}
