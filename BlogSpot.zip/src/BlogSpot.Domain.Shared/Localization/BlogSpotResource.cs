﻿using Volo.Abp.Localization;

namespace BlogSpot.Localization;

[LocalizationResourceName("BlogSpot")]
public class BlogSpotResource
{

}
