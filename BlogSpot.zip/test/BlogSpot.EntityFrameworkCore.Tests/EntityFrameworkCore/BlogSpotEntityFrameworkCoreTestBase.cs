﻿using Volo.Abp;

namespace BlogSpot.EntityFrameworkCore;

public abstract class BlogSpotEntityFrameworkCoreTestBase : BlogSpotTestBase<BlogSpotEntityFrameworkCoreTestModule>
{

}
