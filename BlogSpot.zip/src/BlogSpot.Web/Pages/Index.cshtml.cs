﻿namespace BlogSpot.Web.Pages;

public class IndexModel : BlogSpotPageModel
{
    public void OnGet()
    {

    }
}
