﻿namespace BlogSpot.Permissions;

public static class BlogSpotPermissions
{
    public const string GroupName = "BlogSpot";

    //Add your own permission names. Example:
    //public const string MyPermission1 = GroupName + ".MyPermission1";
}
