﻿namespace BlogSpot;

public abstract class BlogSpotApplicationTestBase : BlogSpotTestBase<BlogSpotApplicationTestModule>
{

}
