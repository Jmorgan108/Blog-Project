﻿using AutoMapper;

namespace BlogSpot.Web;

public class BlogSpotWebAutoMapperProfile : Profile
{
    public BlogSpotWebAutoMapperProfile()
    {
        //Define your AutoMapper configuration here for the Web project.
    }
}
