﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("BlogSpot.Domain.Tests")]
[assembly:InternalsVisibleToAttribute("BlogSpot.TestBase")]
