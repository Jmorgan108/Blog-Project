﻿namespace BlogSpot;

public abstract class BlogSpotDomainTestBase : BlogSpotTestBase<BlogSpotDomainTestModule>
{

}
