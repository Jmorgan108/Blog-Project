﻿namespace BlogSpot;

public static class BlogSpotConsts
{
    public const string DbTablePrefix = "App";

    public const string DbSchema = null;
}
